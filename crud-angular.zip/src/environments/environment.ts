export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyDFR_EFe17oeJPmr3Xs1M2iyVfGpqYYbAw",
    authDomain: "crud-angular-firebase-6f4fc.firebaseapp.com",
    projectId: "crud-angular-firebase-6f4fc",
    storageBucket: "crud-angular-firebase-6f4fc.appspot.com",
    messagingSenderId: "81360072469",
    appId: "1:81360072469:web:86d3db3414e937cfbb031c"
  }
};